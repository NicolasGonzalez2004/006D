/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package streamflex;

/**
 *
 * @author Cetecom
 */
public class Series extends Catalogo {
    private int numeroTemporada;
    private String finalizada;

    public Series() {
    }

    public Series(int numeroTemporada, String finalizada) {
        this.numeroTemporada = numeroTemporada;
        this.finalizada = finalizada;
    }

    public Series(int numeroTemporada, String finalizada, int id, String Recomendada, String TipoContenido) {
        super(id, Recomendada, TipoContenido);
        this.numeroTemporada = numeroTemporada;
        this.finalizada = finalizada;
    }

    public int getNumeroTemporada() {
        return numeroTemporada;
    }

    public void setNumeroTemporada(int numeroTemporada) {
        this.numeroTemporada = numeroTemporada;
    }

    public String getFinalizada() {
        return finalizada;
    }

    public void setFinalizada(String finalizada) {
        this.finalizada = finalizada;
    }

    @Override
    public String toString() {
        return "Series{" + "numeroTemporada=" + numeroTemporada + ", finalizada=" + finalizada + '}';
    }
    
    
    
    
}
