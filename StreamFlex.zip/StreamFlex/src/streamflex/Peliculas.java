/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package streamflex;

/**
 *
 * @author Cetecom
 */
public class Peliculas extends Catalogo{
    private int duracion ;
    private int calificacion ;

    public Peliculas() {
    }

    public Peliculas(int duracion, int calificacion) {
        this.duracion = duracion;
        this.calificacion = calificacion;
    }

    public Peliculas(int duracion, int calificacion, int id, String Recomendada, String TipoContenido) {
        super(id, Recomendada, TipoContenido);
        this.duracion = duracion;
        this.calificacion = calificacion;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }

    public int getCalificacion() {
        return calificacion;
    }

    public void setCalificacion(int calificacion) {
        this.calificacion = calificacion;
    }

    @Override
    public String toString() {
        return "Peliculas{" + "duracion=" + duracion + ", calificacion=" + calificacion + '}';
    }

    
    
    
    
    
}
