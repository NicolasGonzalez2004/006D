/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package streamflex;

/**
 *
 * @author Cetecom
 */
public abstract class Catalogo {
    private int id;
    private String Recomendada ;
    private String TipoContenido;

    public Catalogo() {
    }

    public Catalogo(int id, String Recomendada, String TipoContenido) {
        this.id = id;
        this.Recomendada = Recomendada;
        this.TipoContenido = TipoContenido;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRecomendada() {
        return Recomendada;
    }

    public void setRecomendada(String Recomendada) {
        this.Recomendada = Recomendada;
    }

    public String getTipoContenido() {
        return TipoContenido;
    }

    public void setTipoContenido(String TipoContenido) {
        this.TipoContenido = TipoContenido;
    }

    @Override
    public String toString() {
        return "Catalogo{" + "id=" + id + ", Recomendada=" + Recomendada + ", TipoContenido=" + TipoContenido + '}';
    }
    
    
}
