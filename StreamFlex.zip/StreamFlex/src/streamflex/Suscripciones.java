/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package streamflex;

/**
 *
 * @author Cetecom
 */
public class Suscripciones {
     private int run ;

    public Suscripciones() {
    }

    public Suscripciones(int run) {
        this.run = run;
    }

    public int getRun() {
        return run;
    }

    public void setRun(int run) {
        this.run = run;
    }

    @Override
    public String toString() {
        return "Suscripciones{" + "run=" + run + '}';
    }



        
        
}
    
    
    
    

