/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package streamflex;
import java.util.Scanner;
/**
 *
 * @author Cetecom
 */
public class StreamFlex {


    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int opcion = 0;
        while (opcion !=5){
        System.out.println("****Catalogo***");
        System.out.println("1.Peliculas");
        System.out.println("2.Series");
        System.out.println("3.Suscripcion ");
        System.out.println("4.Documentales");
        System.out.println("5.Salir");  
        
       
        
        
        opcion = entrada.nextInt();
        entrada.nextLine();
        
        switch (opcion){
            case 1 :
                int opciones = 0;
                System.out.println("Peliculas");
                System.out.println("Peliclas disponibles");
                System.out.println("1.La monja (DURACION 2HRS)");
                System.out.println("2.Cars (DURACION 1 HRS 30 MIN)");
                System.out.println("3.El conjuro(Duracion 2hrs 30 min)");
                opciones = entrada.nextInt();
                entrada.nextLine();
                

                
                
            break;
                
            case 2: 
                
                System.out.println("Series");
                System.out.println("Series disponibles");
                System.out.println("1.Riverdale [6 temporadas]");
                System.out.println("2.One piece 1121 capitulos ");
                opciones = entrada .nextInt();
                entrada.nextLine();
                
                switch (opciones ){
                    case 1:
                        System.out.println("Serie elegida riverdale");
                        System.out.println("Serie elegida one piece");
                }
            break;
                
            case 3: 
                System.out.println("Suscripcion");
            break;
                
            case 4 : 
                System.out.println("Documentales");
                System.out.println("Vida en el oceano [ 2 temporadas]");
                System.out.println("Supervivencia en la selva [3 temporadas]");
            break;
        }
           
        
        }
    }
    
}
